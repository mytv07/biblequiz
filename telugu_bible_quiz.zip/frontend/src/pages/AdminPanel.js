import React from 'react';
export default function AdminPanel() {
  return <h1>Admin Panel</h1>;
}