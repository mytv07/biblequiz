import React from 'react';
export default function Quiz() {
  return <h1>Take Quiz Page</h1>;
}