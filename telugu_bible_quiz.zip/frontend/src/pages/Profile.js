import React from 'react';
export default function Profile() {
  return <h1>User Profile Page</h1>;
}