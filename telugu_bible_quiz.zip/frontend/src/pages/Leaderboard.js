import React from 'react';
export default function Leaderboard() {
  return <h1>Leaderboard Page</h1>;
}