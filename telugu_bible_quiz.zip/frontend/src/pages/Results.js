import React from 'react';
export default function Results() {
  return <h1>Quiz Results Page</h1>;
}